# Frametta

Art-framing mockup app — see your artwork framed and hung in a real room
before ordering a physical frame.

## Quick start

```bash
npm install
npm run dev
```

Opens a local dev server (prints the URL to visit — usually
`http://localhost:5173`).

## Build for production

```bash
npm run build
```

Outputs a static site to `dist/` — this is what gets deployed to a web host,
or fed into Capacitor for a native mobile build.

## What's in here

- `src/App.jsx` — the entire app. One large component (`Frametta`), all
  frame/interior assets embedded as base64 so there's no separate asset
  pipeline to manage.
- `src/main.jsx` — mounts it.

## Current status

- **Web app, fully working.** Not yet packaged as a native iOS/Android app.
- **Monetization UI is built** (paywall, watermarking, free/paid frame and
  interior gating) but the actual purchase button currently just flips a
  local on/off switch — real Apple/Google in-app purchase billing is not
  wired up yet.
- **Live Camera** uses the browser's camera API directly. Works as a web
  feature; will likely need adjusting to Capacitor's `@capacitor/camera`
  plugin once this becomes a native app, for reliable permissions handling.

## Turning this into a mobile app

See `frametta-mobile-conversion-guide.md` in this same folder — Capacitor
setup, Android + Play Store steps, iOS + App Store steps.

## App icon & splash screen

`resources/icon.png` (1024×1024) and `resources/splash.png` (2732×2732) are
included — designed to match the app's actual wood-frame palette and dark UI
theme. After adding Capacitor (see the guide), generate every platform-specific
size automatically with:

```bash
npm install @capacitor/assets --save-dev
npx capacitor-assets generate
```

This reads the two files in `resources/` and writes out every required icon
and splash size for both `android/` and `ios/` automatically — no manual
resizing needed.
